# API de Autenticação com JWT

Projeto simples com cadastro, login e autenticação usando Java, Spring Boot e JWT.

## Como executar

1. Configure o banco de dados PostgreSQL e ajuste o `application.properties`.
2. Rode com: `mvn spring-boot:run`
3. Use `/register`, `/login` e `/profile` para testar os endpoints.